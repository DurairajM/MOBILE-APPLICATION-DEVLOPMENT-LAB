package com.example.gs;
import org.json.JSONObject;
interface AsyncResult
{
    void onResult(JSONObject object);
}