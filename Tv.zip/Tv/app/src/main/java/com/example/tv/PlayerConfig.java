package com.example.tv;

public class PlayerConfig {
    PlayerConfig()
    {
    }
    public static final String
            API_KEY="AIzaSyCBMfw7l2n0uyXRPjmp_TpeDsGGpyFdwUs";
}